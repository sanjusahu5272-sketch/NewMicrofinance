from datetime import timedelta
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient
from .models import Branch, Area, Centre, Member, Employee, AttendanceRecord, EmployeeLeaveRequest


class V181MenuLogicTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.maker = User.objects.create_user(username='v181-maker', password='test-pass-123', is_staff=True)
        self.approver = User.objects.create_user(username='v181-approver', password='test-pass-123', is_staff=True)
        self.client = APIClient(); self.client.force_authenticate(self.maker)
        self.branch = Branch.objects.create(name='V181 Branch', code='V181')
        self.area = Area.objects.create(branch=self.branch, name='A1', code='A1')
        self.centre = Centre.objects.create(area=self.area, name='C1')
        self.other_centre = Centre.objects.create(area=self.area, name='C2')
        self.member = Member.objects.create(branch=self.branch, centre=self.centre, member_no='V181-M1', name='M One', phone='9000000001')
        self.outsider = Member.objects.create(branch=self.branch, centre=self.other_centre, member_no='V181-M2', name='M Two', phone='9000000002')
        self.emp = Employee.objects.create(branch=self.branch, employee_no='V181-E1', name='Emp', phone='9000000003', casual_leave_days=3)

    def _leave(self, **kw):
        today = timezone.localdate()
        body = {'employee': self.emp.pk, 'leave_type': 'casual', 'from_date': str(today), 'to_date': str(today + timedelta(days=1)), 'reason': 'test'}
        body.update(kw)
        return self.client.post('/api/employee-leaves/', body, format='json')

    def test_leave_approval_deducts_balance_and_marks_attendance(self):
        r = self._leave(); self.assertEqual(r.status_code, 201, r.data); self.assertEqual(r.data['days'], 2)
        pk = r.data['id']
        self.assertEqual(self.client.post(f'/api/employee-leaves/{pk}/approve/', {}, format='json').status_code, 403)  # maker-checker
        self.client.force_authenticate(self.approver)
        ok = self.client.post(f'/api/employee-leaves/{pk}/approve/', {'approval_note': 'ok'}, format='json')
        self.assertEqual(ok.status_code, 200, ok.data)
        self.emp.refresh_from_db(); self.assertEqual(self.emp.casual_leave_days, 1)
        self.assertEqual(AttendanceRecord.objects.filter(employee=self.emp, status='leave').count(), 2)
        self.assertEqual(self.client.post(f'/api/employee-leaves/{pk}/approve/', {}, format='json').status_code, 409)

    def test_leave_rejects_insufficient_balance_and_overlap(self):
        self.assertEqual(self._leave(to_date=str(timezone.localdate() + timedelta(days=9))).status_code, 400)
        self.assertEqual(self._leave().status_code, 201)
        self.assertEqual(self._leave().status_code, 400)

    def test_centre_leader_must_belong_to_centre(self):
        bad = self.client.patch(f'/api/centres/{self.centre.pk}/', {'leader': self.outsider.pk}, format='json')
        self.assertEqual(bad.status_code, 400)
        good = self.client.patch(f'/api/centres/{self.centre.pk}/', {'leader': self.member.pk}, format='json')
        self.assertEqual(good.status_code, 200, good.data)

    def test_mark_deceased(self):
        url = f'/api/members/{self.member.pk}/mark-deceased/'
        self.assertEqual(self.client.post(url, {'note': 'x'}, format='json').status_code, 400)
        ok = self.client.post(url, {'note': 'Family informed branch'}, format='json'); self.assertEqual(ok.status_code, 200, ok.data)
        self.member.refresh_from_db(); self.assertFalse(self.member.active); self.assertIsNotNone(self.member.deceased_on)
        self.assertEqual(self.client.post(url, {'note': 'Family informed branch'}, format='json').status_code, 409)
        self.assertEqual(len(self.client.get('/api/members/?deceased=1').data['results']), 1)

    def test_member_attendance_rules(self):
        today = str(timezone.localdate())
        base = {'member': self.member.pk, 'centre': self.centre.pk, 'meeting_date': today, 'status': 'present'}
        self.assertEqual(self.client.post('/api/member-attendance/', base, format='json').status_code, 201)
        self.assertEqual(self.client.post('/api/member-attendance/', {**base, 'member': self.outsider.pk}, format='json').status_code, 400)
        self.assertEqual(self.client.post('/api/member-attendance/', {**base, 'meeting_date': str(timezone.localdate() + timedelta(days=2))}, format='json').status_code, 400)
