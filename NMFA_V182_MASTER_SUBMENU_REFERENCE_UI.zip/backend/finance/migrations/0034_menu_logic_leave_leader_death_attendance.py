from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('finance', '0033_loanproduct_reference_plan_fields'),
    ]
    operations = [
        migrations.AddField(model_name='centre', name='leader', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='led_centres', to='finance.member', help_text='Centre leader; must be an active, living member of this centre.')),
        migrations.AddField(model_name='member', name='deceased_on', field=models.DateField(blank=True, null=True)),
        migrations.AddField(model_name='member', name='death_note', field=models.CharField(blank=True, default='', max_length=255)),
        migrations.AlterField(model_name='depositaccount', name='account_type', field=models.CharField(choices=[('savings', 'Savings'), ('recurring', 'Recurring Deposit'), ('fixed', 'Fixed Deposit'), ('security', 'Advance Security')], default='savings', max_length=20)),
        migrations.CreateModel(
            name='EmployeeLeaveRequest',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('leave_type', models.CharField(choices=[('sick', 'Sick'), ('privilege', 'Privilege'), ('mandatory', 'Mandatory'), ('casual', 'Casual'), ('paternity', 'Paternity'), ('maternity', 'Maternity'), ('extraordinary', 'Extraordinary')], max_length=20)),
                ('from_date', models.DateField()),
                ('to_date', models.DateField()),
                ('days', models.PositiveSmallIntegerField(default=0, help_text='Calendar days, inclusive. Calculated by the server.')),
                ('reason', models.TextField(blank=True)),
                ('status', models.CharField(choices=[('pending', 'Pending Approval'), ('approved', 'Approved'), ('rejected', 'Rejected'), ('cancelled', 'Cancelled')], default='pending', max_length=20)),
                ('decision_note', models.TextField(blank=True)),
                ('decided_at', models.DateTimeField(blank=True, null=True)),
                ('created_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='leave_requests_created', to=settings.AUTH_USER_MODEL)),
                ('decided_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='leave_requests_decided', to=settings.AUTH_USER_MODEL)),
                ('employee', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='leave_requests', to='finance.employee')),
            ],
            options={'ordering': ['-from_date', '-id']},
        ),
        migrations.AddConstraint(model_name='employeeleaverequest', constraint=models.CheckConstraint(condition=models.Q(('to_date__gte', models.F('from_date'))), name='leave_to_not_before_from')),
        migrations.CreateModel(
            name='MemberMeetingAttendance',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('meeting_date', models.DateField()),
                ('status', models.CharField(choices=[('present', 'Present'), ('absent', 'Absent'), ('leave', 'On leave')], default='present', max_length=20)),
                ('note', models.CharField(blank=True, max_length=255)),
                ('centre', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='member_attendance', to='finance.centre')),
                ('created_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='member_attendance_created', to=settings.AUTH_USER_MODEL)),
                ('member', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='meeting_attendance', to='finance.member')),
            ],
            options={'ordering': ['-meeting_date', 'member__name']},
        ),
        migrations.AddConstraint(model_name='membermeetingattendance', constraint=models.UniqueConstraint(fields=('member', 'meeting_date'), name='uniq_member_meeting_date')),
    ]
