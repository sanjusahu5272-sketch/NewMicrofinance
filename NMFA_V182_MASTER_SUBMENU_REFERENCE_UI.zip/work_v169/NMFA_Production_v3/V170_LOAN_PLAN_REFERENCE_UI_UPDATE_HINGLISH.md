V170 — Loan Plan Reference UI Update

Scope: UI-only changes for the Loan Plan page based on the supplied UMANG reference recording.

Updated:
- Loan Plan list table uses the reference's nine headings: SR. NO., PLAN NAME, PLAN TYPE, LOAN, DISBURSEMENT, COLLECTION, TENURE, STATUS, ACTION.
- Added Show entries at the left and a search field with search icon button at the right.
- Added reference-style compact table header/rows, green ACTIVE badge, Task dropdown, and numbered pagination.
- Tuned modal header, font weights, input borders, colors, and SAVE / Calculate EMI / CANCEL button styling.
- Updated both bundled frontend source copies so the nested Docker build context and root copy stay aligned.

Safety:
- Backend and database schema were not changed.
- Table amounts use existing API fields where present; if a disbursement-specific field is absent, the displayed disbursement falls back to the plan/loan amount. Confirm the exact business field mapping before relying on that column for financial reporting.

Verification:
- Source-level changes and CSS selectors were inspected.
- npm build was not completed in this environment: npm dependencies were not installed and the install attempt timed out. Run `docker compose build --no-cache frontend` and visually compare the browser output against the reference before production use.
